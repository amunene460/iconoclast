import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer, collection, getDocs, setDoc } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { MACHINES } from './constants';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

// Connection test as per guidelines
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('the client is offline')) {
        console.error("Please check your Firebase configuration. The client is offline.");
      } else if (error.message.includes('permission')) {
        // Silent fail for permission errors in test connection
        console.warn("Connection test: Permission denied (expected if rules are strict).");
      }
    }
  }
}

testConnection();

export async function seedMachines() {
  try {
    const machinesSnap = await getDocs(collection(db, 'machines'));
    if (machinesSnap.empty) {
      console.log('Seeding machines...');
      for (const machine of MACHINES) {
        await setDoc(doc(db, 'machines', machine.id), machine);
      }
      console.log('Seeding complete.');
    }
  } catch (error) {
    console.error('Error seeding machines:', error);
  }
}
