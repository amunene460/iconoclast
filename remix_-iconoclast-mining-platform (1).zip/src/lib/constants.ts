export const CURRENCY = 'KSh';

export const MACHINES = [
  {
    id: 'laptop-m1',
    name: 'Standard Mining Laptop',
    description: 'Entry-level mining device for beginners. Low power consumption.',
    price: 5000,
    dailyIncome: 350,
    category: 'tech',
    stock: 50,
    imageUrl: 'https://images.unsplash.com/photo-1517336714460-4c50d9178024?auto=format&fit=crop&q=80&w=1000',
    stats: { hashrate: '12 MH/s', power: '45W' }
  },
  {
    id: 'laptop-m2',
    name: 'Pro Mining Laptop',
    description: 'Balanced performance for consistent daily returns.',
    price: 15000,
    dailyIncome: 1200,
    category: 'tech',
    stock: 30,
    imageUrl: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&q=80&w=1000',
    stats: { hashrate: '45 MH/s', power: '65W' }
  },
  {
    id: 'gpu-rig-1',
    name: 'Advanced GPU Rig',
    description: 'High-yield GPU rig for serious investors.',
    price: 50000,
    dailyIncome: 4500,
    category: 'electronics',
    stock: 15,
    imageUrl: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&q=80&w=1000',
    stats: { hashrate: '250 MH/s', power: '800W' }
  },
  {
    id: 'vip-rig-1',
    name: 'VIP Diamond Rig',
    description: 'Exclusive high-margin machine for VIP investors. Maximum profit.',
    price: 150000,
    dailyIncome: 15000,
    category: 'high-end',
    stock: 5,
    imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc48?auto=format&fit=crop&q=80&w=1000',
    stats: { hashrate: '1.5 GH/s', power: '2200W' }
  },
  {
    id: 'vip-rig-2',
    name: 'VIP Elite Server',
    description: 'Enterprise-grade mining server. The pinnacle of mining technology.',
    price: 500000,
    dailyIncome: 55000,
    category: 'high-end',
    stock: 2,
    imageUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=1000',
    stats: { hashrate: '5 GH/s', power: '3500W' }
  }
];
