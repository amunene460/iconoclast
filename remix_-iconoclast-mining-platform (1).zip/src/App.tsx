import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './lib/AuthContext';
import { seedMachines } from './lib/firebase';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Marketplace from './pages/Marketplace';
import MyMachines from './pages/MyMachines';
import Wallet from './pages/Wallet';
import Admin from './pages/Admin';
import Landing from './pages/Landing';
import FAQ from './pages/FAQ';
import Support from './pages/Support';
import Settings from './pages/Settings';
import Auth from './pages/Auth';

function ProtectedRoute({ children, adminOnly = false }: { children: React.ReactNode, adminOnly?: boolean }) {
  const { user, profile, loading } = useAuth();

  if (loading) return <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center text-white font-mono">INITIALIZING_SYSTEM...</div>;
  if (!user) return <Navigate to="/auth" />;
  if (adminOnly && profile?.role !== 'admin') return <Navigate to="/dashboard" />;

  return <>{children}</>;
}

function DataInitializer() {
  const { profile } = useAuth();
  
  React.useEffect(() => {
    if (profile?.role === 'admin') {
      seedMachines();
    }
  }, [profile]);

  return null;
}

export default function App() {
  return (
    <AuthProvider>
      <DataInitializer />
      <Router>
        <Routes>
          <Route path="/" element={<Auth />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/*" element={
            <ProtectedRoute>
              <Layout>
                <Routes>
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/marketplace" element={<Marketplace />} />
                  <Route path="/machines" element={<MyMachines />} />
                  <Route path="/wallet" element={<Wallet />} />
                  <Route path="/faq" element={<FAQ />} />
                  <Route path="/support" element={<Support />} />
                  <Route path="/settings" element={<Settings />} />
                  <Route path="/admin" element={<ProtectedRoute adminOnly><Admin /></ProtectedRoute>} />
                </Routes>
              </Layout>
            </ProtectedRoute>
          } />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
