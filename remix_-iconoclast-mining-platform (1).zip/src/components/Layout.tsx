import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext';
import { 
  LayoutDashboard, 
  ShoppingCart, 
  Cpu, 
  Wallet, 
  ShieldCheck, 
  LogOut,
  Menu,
  X,
  User,
  TrendingUp,
  Sun,
  Moon,
  HelpCircle,
  Settings,
  MessageSquare,
  Github,
  Twitter,
  Linkedin,
  Zap,
  Bell,
  ChevronRight,
  Activity,
  BarChart3,
  BookOpen,
  PhoneCall,
  Globe,
  Shield
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { doc, updateDoc, increment, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { CURRENCY } from '../lib/constants';

function ProbabilityWidget() {
  return (
    <div className="bg-foreground/5 border border-custom rounded-3xl p-6 mb-8">
      <div className="flex justify-between items-center mb-4">
        <h4 className="text-sm font-bold text-foreground">Win Probability</h4>
        <span className="text-[10px] font-bold text-money-green bg-money-green/10 px-2 py-1 rounded-full">+5.2%</span>
      </div>
      <div className="text-center mb-4">
        <span className="text-5xl font-black text-money-orange">78.5%</span>
        <p className="text-[10px] text-foreground/40 uppercase tracking-widest mt-1">Success Rate</p>
      </div>
      <div className="h-2 bg-foreground/10 rounded-full overflow-hidden mb-6">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: '78.5%' }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="h-full bg-linear-to-r from-money-orange to-money-gold"
        />
      </div>
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: 'Trades', value: '1,234' },
          { label: 'Win Rate', value: '78%' },
          { label: 'Factor', value: '2.4' }
        ].map((stat, i) => (
          <div key={i} className="bg-foreground/5 p-2 rounded-xl text-center">
            <p className="text-lg font-bold text-money-orange leading-none mb-1">{stat.value}</p>
            <p className="text-[8px] text-foreground/40 uppercase tracking-tighter">{stat.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const { profile, logout, loginAdmin } = useAuth();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [isDarkMode, setIsDarkMode] = React.useState(true);
  const [logoClicks, setLogoClicks] = React.useState(0);
  const [showAdminLogin, setShowAdminLogin] = React.useState(false);
  const [adminEmail, setAdminEmail] = React.useState('');
  const [adminPass, setAdminPass] = React.useState('');
  const [adminError, setAdminError] = React.useState('');

  React.useEffect(() => {
    if (logoClicks >= 5) {
      setShowAdminLogin(true);
      setLogoClicks(0);
    }
  }, [logoClicks]);

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError('');
    try {
      await loginAdmin(adminEmail, adminPass);
      setShowAdminLogin(false);
      setAdminEmail('');
      setAdminPass('');
    } catch (err: any) {
      setAdminError('Invalid admin credentials');
    }
  };

  React.useEffect(() => {
    if (!isDarkMode) {
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
    }
  }, [isDarkMode]);

  React.useEffect(() => {
    // Track site visit
    const trackVisit = async () => {
      const statsRef = doc(db, 'system', 'stats');
      const snap = await getDoc(statsRef);
      if (snap.exists()) {
        await updateDoc(statsRef, {
          siteVisits: increment(1)
        });
      } else {
        await setDoc(statsRef, {
          totalInvestors: 0,
          totalDeposits: 0,
          totalWithdrawals: 0,
          totalProfit: 0,
          siteVisits: 1,
          isMaintenanceMode: false
        });
      }
    };
    trackVisit();
  }, []);

  const navItems = [
    { section: 'Main Menu', items: [
      { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
      { name: 'Marketplace', path: '/marketplace', icon: ShoppingCart, badge: '20' },
      { name: 'My Machines', path: '/machines', icon: Cpu },
      { name: 'Analytics', path: '/analytics', icon: BarChart3 },
    ]},
    { section: 'Services', items: [
      { name: 'Wallet', path: '/wallet', icon: Wallet },
      { name: 'M-PESA', path: '/mpesa', icon: Zap },
      { name: 'Visa Payments', path: '/visa', icon: Globe },
    ]},
    { section: 'Support', items: [
      { name: 'FAQ', path: '/faq', icon: HelpCircle },
      { name: 'Support', path: '/support', icon: MessageSquare },
      { name: 'Settings', path: '/settings', icon: Settings },
    ]}
  ];

  // Admin section is hidden from regular nav, only accessible via direct URL or hidden trigger
  // if (profile?.role === 'admin') {
  //   navItems.push({
  //     section: 'Admin',
  //     items: [
  //       { name: 'Admin Terminal', path: '/admin', icon: Shield }
  //     ]
  //   });
  // }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans selection:bg-money-orange/30">
      {/* Sidebar - Desktop */}
      <aside className="fixed left-0 top-0 h-full w-[300px] bg-sidebar backdrop-blur-xl border-r border-custom hidden lg:flex flex-col z-50 overflow-y-auto">
        <div className="p-8 text-center cursor-pointer" onClick={() => setLogoClicks(prev => prev + 1)}>
          <div className="w-16 h-16 bg-linear-to-br from-money-orange to-money-gold rounded-2xl flex items-center justify-center shadow-2xl shadow-money-orange/20 mx-auto mb-4">
            <TrendingUp className="text-black w-10 h-10" />
          </div>
          <h2 className="font-black text-2xl tracking-tighter bg-linear-to-r from-foreground to-money-orange bg-clip-text text-transparent">ICONOCLAST</h2>
        </div>

        <div className="px-6 mb-8">
          <div className="bg-foreground/5 border border-custom rounded-3xl p-6 text-center">
            <div className="w-20 h-20 bg-linear-to-br from-money-orange to-money-gold rounded-full flex items-center justify-center text-4xl font-black text-black mx-auto mb-4 shadow-xl">
              {profile?.displayName?.charAt(0).toUpperCase() || 'G'}
            </div>
            <h4 className="font-bold text-lg">{profile?.displayName || 'Guest User'}</h4>
            <p className="text-xs text-foreground/40">{profile?.email || 'Sign in to access features'}</p>
            {!profile && (
              <Link 
                to="/auth"
                className="w-full mt-4 bg-linear-to-r from-money-orange to-money-gold text-black font-bold py-2 rounded-xl text-sm hover:scale-105 transition-transform inline-block"
              >
                Sign In / Register
              </Link>
            )}
          </div>
        </div>

        <div className="px-6">
          <ProbabilityWidget />
        </div>

        <nav className="flex-1 px-6 pb-10 space-y-8">
          {navItems.map((section) => (
            <div key={section.section}>
              <h4 className="text-[10px] font-black text-foreground/30 uppercase tracking-[0.2em] mb-4 ml-4">{section.section}</h4>
              <div className="space-y-1">
                {section.items.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={cn(
                      "flex items-center gap-3 px-4 py-3 rounded-2xl transition-all duration-300 group relative overflow-hidden",
                      location.pathname === item.path 
                        ? "bg-money-orange/10 text-money-orange font-bold border border-money-orange/20" 
                        : "hover:bg-foreground/5 text-foreground/60 hover:text-foreground"
                    )}
                  >
                    <item.icon className={cn("w-5 h-5", location.pathname === item.path ? "text-money-orange" : "text-foreground/40 group-hover:text-money-orange")} />
                    <span className="text-sm">{item.name}</span>
                    {item.badge && (
                      <span className="ml-auto bg-money-orange text-black text-[10px] font-black px-2 py-0.5 rounded-full">
                        {item.badge}
                      </span>
                    )}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </nav>

        <div className="p-6 border-t border-custom mt-auto">
          <div className="flex items-center justify-between text-xs text-foreground/40">
            <span>Network: Mainnet</span>
            <span className="flex items-center gap-1.5 text-money-green font-bold">
              <span className="w-1.5 h-1.5 bg-money-green rounded-full animate-pulse" />
              Live
            </span>
          </div>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 left-0 w-full bg-sidebar backdrop-blur-xl border-b border-custom p-4 flex items-center justify-between z-50">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setLogoClicks(prev => prev + 1)}>
          <TrendingUp className="text-money-orange w-6 h-6" />
          <span className="font-black text-xl tracking-tighter">ICONOCLAST</span>
        </div>
        <div className="flex items-center gap-4">
          <button onClick={() => setIsDarkMode(!isDarkMode)} className="text-foreground/60">
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-foreground">
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-[60]">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="absolute left-0 top-0 h-full w-[280px] bg-sidebar border-r border-custom flex flex-col overflow-y-auto"
            >
              <div className="p-8 text-center cursor-pointer" onClick={() => setLogoClicks(prev => prev + 1)}>
                <div className="w-12 h-12 bg-linear-to-br from-money-orange to-money-gold rounded-xl flex items-center justify-center shadow-lg mx-auto mb-3">
                  <TrendingUp className="text-black w-8 h-8" />
                </div>
                <h2 className="font-black text-xl tracking-tighter">ICONOCLAST</h2>
              </div>

              <div className="px-6 mb-6">
                <div className="bg-foreground/5 border border-custom rounded-2xl p-4 text-center">
                  <div className="w-12 h-12 bg-linear-to-br from-money-orange to-money-gold rounded-full flex items-center justify-center text-xl font-black text-black mx-auto mb-2">
                    {profile?.displayName?.charAt(0).toUpperCase() || 'G'}
                  </div>
                  <h4 className="font-bold text-sm truncate">{profile?.displayName || 'Guest User'}</h4>
                </div>
              </div>

              <div className="px-6 mb-6">
                <ProbabilityWidget />
              </div>

              <nav className="flex-1 px-4 space-y-6 pb-10">
                {navItems.map((section) => (
                  <div key={section.section}>
                    <h4 className="text-[8px] font-black text-foreground/30 uppercase tracking-[0.2em] mb-3 ml-2">{section.section}</h4>
                    <div className="space-y-1">
                      {section.items.map((item) => (
                        <Link
                          key={item.path}
                          to={item.path}
                          onClick={() => setIsMobileMenuOpen(false)}
                          className={cn(
                            "flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-sm font-bold",
                            location.pathname === item.path 
                              ? "bg-linear-to-br from-money-orange to-money-gold text-black" 
                              : "text-foreground/40 hover:text-foreground"
                          )}
                        >
                          <item.icon size={18} />
                          {item.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
                
                {!profile && (
                  <Link 
                    to="/auth"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="flex items-center gap-3 w-full px-4 py-3 rounded-xl bg-linear-to-br from-money-orange to-money-gold text-black text-sm font-bold mt-4"
                  >
                    <User size={18} />
                    Sign In / Register
                  </Link>
                )}
                
                {profile && (
                  <button 
                    onClick={logout}
                    className="flex items-center gap-3 w-full px-4 py-3 rounded-xl bg-money-red/10 text-money-red text-sm font-bold mt-4"
                  >
                    <LogOut size={18} />
                    Logout
                  </button>
                )}
              </nav>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Admin Login Modal */}
      <AnimatePresence>
        {showAdminLogin && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAdminLogin(false)}
              className="absolute inset-0 bg-black/90 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-md bg-background border border-white/10 rounded-[40px] p-10 shadow-2xl"
            >
              <h3 className="text-3xl font-black text-white tracking-tighter mb-6 text-center">ADMIN ACCESS</h3>
              <form onSubmit={handleAdminLogin} className="space-y-6">
                <div>
                  <label className="text-[10px] font-black text-foreground/40 uppercase tracking-widest mb-2 block">Admin Email</label>
                  <input 
                    type="email" 
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="w-full bg-foreground/5 border border-custom rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-money-orange"
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-foreground/40 uppercase tracking-widest mb-2 block">Password</label>
                  <input 
                    type="password" 
                    value={adminPass}
                    onChange={(e) => setAdminPass(e.target.value)}
                    className="w-full bg-foreground/5 border border-custom rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-money-orange"
                    required
                  />
                </div>
                {adminError && <p className="text-money-red text-xs font-bold text-center">{adminError}</p>}
                <button 
                  type="submit"
                  className="w-full py-5 rounded-2xl bg-linear-to-br from-money-orange to-money-gold text-black font-black text-lg uppercase tracking-widest shadow-xl shadow-money-orange/20"
                >
                  AUTHORIZE
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="lg:ml-[300px] pt-20 lg:pt-0 flex-1 flex flex-col">
        {/* Top Nav - Desktop */}
        <div className="hidden lg:flex items-center justify-between px-10 py-6 bg-background/80 backdrop-blur-md border-b border-custom sticky top-0 z-40">
          <h1 className="text-3xl font-black tracking-tighter">
            Mining <span className="text-money-orange">Dashboard</span>
          </h1>
          <div className="flex items-center gap-6">
            <button className="relative text-foreground/60 hover:text-foreground transition-colors">
              <Bell size={24} />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-money-orange rounded-full" />
            </button>
            <div className="flex items-center gap-3 bg-foreground/5 border border-custom px-4 py-2 rounded-2xl">
              <Globe size={18} className="text-money-orange" />
              <select className="bg-transparent text-sm font-bold focus:outline-none cursor-pointer text-blue-300">
                <option value="USD">USD</option>
                <option value="KES">KES</option>
                <option value="EUR">EUR</option>
              </select>
            </div>
            <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="w-10 h-10 bg-foreground/5 border border-custom rounded-xl flex items-center justify-center hover:bg-foreground/10 transition-colors"
            >
              {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            {profile && (
              <button 
                onClick={logout}
                className="flex items-center gap-2 text-foreground/40 hover:text-money-red transition-colors text-sm font-bold"
              >
                <LogOut size={18} />
                Logout
              </button>
            )}
          </div>
        </div>

        <div className="p-6 lg:p-10 flex-1">
          {children}
        </div>

        {/* Footer */}
        <footer className="bg-sidebar border-t border-custom p-10 lg:p-20">
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            <div className="space-y-6">
              <div className="flex items-center gap-3">
                <TrendingUp className="text-money-orange w-8 h-8" />
                <span className="font-black text-2xl tracking-tighter">ICONOCLAST</span>
              </div>
              <p className="text-sm text-foreground/40 leading-relaxed">
                Revolutionizing cloud mining with transparent, profitable, and secure investment solutions. Built for the future of decentralized wealth.
              </p>
              <div className="bg-money-orange/10 border border-money-orange/20 p-4 rounded-2xl inline-block">
                <p className="text-[10px] font-black text-money-orange uppercase tracking-widest mb-1">M-PESA Paybill</p>
                <p className="font-bold text-foreground">123456</p>
              </div>
              <div className="flex gap-4">
                <a href="#" className="w-10 h-10 bg-foreground/5 rounded-xl flex items-center justify-center text-foreground/40 hover:text-money-orange hover:bg-money-orange/10 transition-all"><Twitter size={20} /></a>
                <a href="#" className="w-10 h-10 bg-foreground/5 rounded-xl flex items-center justify-center text-foreground/40 hover:text-money-orange hover:bg-money-orange/10 transition-all"><Linkedin size={20} /></a>
                <a href="#" className="w-10 h-10 bg-foreground/5 rounded-xl flex items-center justify-center text-foreground/40 hover:text-money-orange hover:bg-money-orange/10 transition-all"><Github size={20} /></a>
              </div>
            </div>
            
            <div>
              <h4 className="font-black text-foreground uppercase tracking-[0.2em] text-xs mb-8">Quick Links</h4>
              <ul className="space-y-4 text-sm text-foreground/40">
                <li><Link to="/marketplace" className="hover:text-money-orange transition-colors">Marketplace</Link></li>
                <li><Link to="/dashboard" className="hover:text-money-orange transition-colors">Dashboard</Link></li>
                <li><Link to="/wallet" className="hover:text-money-orange transition-colors">Wallet</Link></li>
                <li><Link to="/machines" className="hover:text-money-orange transition-colors">My Rigs</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="font-black text-foreground uppercase tracking-[0.2em] text-xs mb-8">Legal</h4>
              <ul className="space-y-4 text-sm text-foreground/40">
                <li><a href="#" className="hover:text-money-orange transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-money-orange transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-money-orange transition-colors">Risk Disclosure</a></li>
                <li><a href="#" className="hover:text-money-orange transition-colors">Cookie Policy</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-black text-foreground uppercase tracking-[0.2em] text-xs mb-8">Contact</h4>
              <ul className="space-y-4 text-sm text-foreground/40">
                <li className="flex items-center gap-3">
                  <PhoneCall size={16} className="text-money-orange" />
                  +254 700 000000
                </li>
                <li className="flex items-center gap-3">
                  <MessageSquare size={16} className="text-money-orange" />
                  support@iconoclast.io
                </li>
                <li className="flex items-center gap-3">
                  <Globe size={16} className="text-money-orange" />
                  Nairobi, Kenya
                </li>
              </ul>
            </div>
          </div>
          <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-custom flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] font-bold text-foreground/20 uppercase tracking-widest">
            <p>© 2026 Iconoclast Mining Platform. All rights reserved.</p>
            <div className="flex gap-6">
              <span className="flex items-center gap-2">USD</span>
              <span className="flex items-center gap-2">KES</span>
              <span className="flex items-center gap-2">EUR</span>
              <span className="flex items-center gap-2">GBP</span>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
