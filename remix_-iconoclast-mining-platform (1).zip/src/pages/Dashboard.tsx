import React, { useEffect, useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Zap, 
  Cpu, 
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Newspaper,
  ShoppingCart,
  Wallet,
  ShieldCheck
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { motion } from 'motion/react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { cn } from '../lib/utils';
import { CURRENCY } from '../lib/constants';
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';

const MOCK_CHART_DATA = [
  { time: '00:00', price: 62000, revenue: 120 },
  { time: '04:00', price: 63500, revenue: 150 },
  { time: '08:00', price: 61000, revenue: 140 },
  { time: '12:00', price: 64000, revenue: 180 },
  { time: '16:00', price: 65200, revenue: 210 },
  { time: '20:00', price: 64800, revenue: 195 },
  { time: '23:59', price: 66000, revenue: 230 },
];

export default function Dashboard() {
  const { profile } = useAuth();
  const [userMachines, setUserMachines] = useState<any[]>([]);
  const [cryptoNews, setCryptoNews] = useState<any[]>([
    { id: 1, title: 'Bitcoin Hits New All-Time High Amid Institutional Inflow', source: 'CryptoDaily', time: '2h ago' },
    { id: 2, title: 'Ethereum 2.0 Staking Reaches Milestone of 30M ETH', source: 'BlockNews', time: '5h ago' },
    { id: 3, title: 'New Mining Regulations Proposed in Major Tech Hubs', source: 'TechCrunch', time: '8h ago' },
  ]);

  useEffect(() => {
    if (!profile) return;
    const path = `users/${profile.uid}/machines`;
    const q = query(collection(db, path));
    const unsub = onSnapshot(q, (snap) => {
      setUserMachines(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });
    return () => unsub();
  }, [profile]);

  const stats = [
    { label: 'Total Balance', value: `${CURRENCY} ${profile?.balance.toFixed(2)}`, icon: TrendingUp, color: 'text-money-orange', bg: 'bg-money-orange/10' },
    { label: 'Active Machines', value: userMachines.length, icon: Cpu, color: 'text-money-blue', bg: 'bg-money-blue/10' },
    { label: 'Daily Revenue', value: `${CURRENCY} ${(userMachines.reduce((acc, m) => acc + m.dailyIncome, 0)).toFixed(2)}`, icon: Zap, color: 'text-money-gold', bg: 'bg-money-gold/10' },
    { label: 'System Uptime', value: '99.98%', icon: Clock, color: 'text-money-green', bg: 'bg-money-green/10' },
  ];

  return (
    <div className="space-y-10">
      {/* Balance Card */}
      <div className="bg-linear-to-br from-[#1a1f2e] to-[#0f1422] border border-custom rounded-[32px] p-8 lg:p-12 flex flex-col lg:flex-row justify-between items-center gap-8 shadow-2xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-64 h-64 bg-money-orange/5 blur-[100px] rounded-full -mr-32 -mt-32 group-hover:bg-money-orange/10 transition-all duration-700" />
        <div className="flex-1 text-center lg:text-left relative z-10">
          <h3 className="text-[10px] font-black text-foreground/40 uppercase tracking-[0.2em] mb-4">Account Balance</h3>
          <div className="text-6xl lg:text-7xl font-black text-foreground tracking-tighter mb-6">
            <span className="text-money-orange">{CURRENCY}</span>{profile?.balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <div className="flex flex-wrap justify-center lg:justify-start gap-10">
            <div>
              <p className="text-[10px] font-black text-foreground/30 uppercase tracking-widest mb-1">Portfolio Value</p>
              <p className="text-2xl font-black text-money-orange">{CURRENCY} {((profile?.balance || 0) * 1.5).toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
            </div>
            <div>
              <p className="text-[10px] font-black text-foreground/30 uppercase tracking-widest mb-1">Active Rigs</p>
              <p className="text-2xl font-black text-foreground">{userMachines.length}</p>
            </div>
          </div>
        </div>
        <div className="bg-money-green/10 border border-money-green/20 p-8 rounded-[24px] text-center lg:text-right min-w-[240px] relative z-10">
          <p className="text-[10px] font-black text-foreground/40 uppercase tracking-widest mb-2">Weekly Profit Margin</p>
          <p className="text-5xl font-black text-money-green">+24.8%</p>
          <p className="text-[10px] font-bold text-money-orange mt-2 uppercase tracking-tighter">Guaranteed min 10%</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="glass-card p-4 lg:p-8 flex flex-col gap-3 lg:gap-4"
          >
            <div className={cn("w-10 h-10 lg:w-12 lg:h-12 rounded-xl lg:rounded-2xl flex items-center justify-center", stat.bg)}>
              <stat.icon size={20} className={stat.color} />
            </div>
            <div>
              <p className="text-[8px] lg:text-[10px] font-black text-foreground/40 uppercase tracking-widest mb-1">{stat.label}</p>
              <p className="text-sm lg:text-2xl font-black text-white tracking-tight">{stat.value}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Market Chart Section */}
        <div className="glass-card p-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-money-orange/10 rounded-lg">
                <TrendingUp className="text-money-orange w-5 h-5" />
              </div>
              <h3 className="text-xl font-bold text-foreground">BTC/USD Market</h3>
            </div>
            <div className="flex gap-2">
              {['1W', '1M', '3M'].map((t) => (
                <button key={t} className={cn("px-3 py-1 rounded-full text-[10px] font-black transition-all", t === '1W' ? "bg-money-orange text-black" : "bg-foreground/5 text-foreground/40 hover:bg-foreground/10")}>
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={MOCK_CHART_DATA}>
                <defs>
                  <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f0b90b" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#f0b90b" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                <XAxis dataKey="time" stroke="#ffffff20" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#ffffff20" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `$${val/1000}k`} />
                <Tooltip contentStyle={{ backgroundColor: '#1a1f2e', border: '1px solid #ffffff10', borderRadius: '12px' }} itemStyle={{ color: '#f0b90b' }} />
                <Area type="monotone" dataKey="price" stroke="#f0b90b" strokeWidth={3} fillOpacity={1} fill="url(#colorPrice)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Revenue Chart Section */}
        <div className="glass-card p-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-money-blue/10 rounded-lg">
                <Activity className="text-money-blue w-5 h-5" />
              </div>
              <h3 className="text-xl font-bold text-foreground">Revenue Growth</h3>
            </div>
            <div className="flex items-center gap-2 text-money-green bg-money-green/10 px-3 py-1 rounded-full text-[10px] font-black">
              +12.3% vs last week
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={MOCK_CHART_DATA}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                <XAxis dataKey="time" stroke="#ffffff20" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#ffffff20" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={{ backgroundColor: '#1a1f2e', border: '1px solid #ffffff10', borderRadius: '12px' }} itemStyle={{ color: '#3b82f6' }} />
                <Area type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* News Section */}
        <div className="lg:col-span-2 bg-card border border-custom rounded-[32px] p-8">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-money-blue/10 rounded-xl flex items-center justify-center">
              <Newspaper className="text-money-blue w-5 h-5" />
            </div>
            <h3 className="text-xl font-bold text-foreground">Market Intelligence</h3>
          </div>
          <div className="space-y-6">
            {cryptoNews.map((news) => (
              <div key={news.id} className="group cursor-pointer p-4 hover:bg-foreground/5 rounded-2xl transition-colors border border-transparent hover:border-custom">
                <p className="text-xs text-money-blue font-bold uppercase tracking-widest mb-2 flex items-center gap-2">
                  {news.source}
                  <span className="w-1 h-1 bg-foreground/20 rounded-full" />
                  <span className="text-foreground/40">{news.time}</span>
                </p>
                <h4 className="text-foreground font-medium group-hover:text-money-orange transition-colors leading-snug text-lg">
                  {news.title}
                </h4>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-card border border-custom rounded-[32px] p-8">
          <h3 className="text-xl font-bold text-foreground mb-8">Quick Actions</h3>
          <div className="space-y-4">
            <button className="w-full flex items-center justify-between p-6 bg-money-orange/10 border border-money-orange/20 rounded-2xl group hover:bg-money-orange transition-all">
              <div className="flex items-center gap-4">
                <ShoppingCart className="text-money-orange group-hover:text-black" />
                <span className="font-bold text-foreground group-hover:text-black">Buy New Rig</span>
              </div>
              <ArrowUpRight className="text-money-orange group-hover:text-black" />
            </button>
            <button className="w-full flex items-center justify-between p-6 bg-money-green/10 border border-money-green/20 rounded-2xl group hover:bg-money-green transition-all">
              <div className="flex items-center gap-4">
                <Wallet className="text-money-green group-hover:text-black" />
                <span className="font-bold text-foreground group-hover:text-black">Withdraw Funds</span>
              </div>
              <ArrowUpRight className="text-money-green group-hover:text-black" />
            </button>
            <button className="w-full flex items-center justify-between p-6 bg-money-gold/10 border border-money-gold/20 rounded-2xl group hover:bg-money-gold transition-all">
              <div className="flex items-center gap-4">
                <ShieldCheck className="text-money-gold group-hover:text-black" />
                <span className="font-bold text-foreground group-hover:text-black">Security Audit</span>
              </div>
              <ArrowUpRight className="text-money-gold group-hover:text-black" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
