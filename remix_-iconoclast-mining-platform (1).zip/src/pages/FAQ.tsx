import React from 'react';
import { motion } from 'motion/react';
import { HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';

const FAQS = [
  {
    q: "How does the mining platform work?",
    a: "Iconoclast Mining Platform allows you to purchase high-performance mining machines. Once purchased, these machines are automatically configured and start generating passive income based on their hash rate and efficiency. You can monitor your earnings in real-time on your dashboard."
  },
  {
    q: "When can I withdraw my profits?",
    a: "Withdrawals are processed every Sunday. You can withdraw your accumulated earnings directly to your bank account or via M-Pesa. The minimum withdrawal amount is $10."
  },
  {
    q: "Can I upgrade my machines?",
    a: "Yes, you can upgrade your existing machines to increase their hash rate and daily income. Upgrades are available in the Marketplace section for active rig owners."
  },
  {
    q: "Is my investment secure?",
    a: "We use military-grade encryption and multi-signature protocols to protect your assets. Our infrastructure is monitored 24/7 to ensure maximum uptime and security."
  },
  {
    q: "What payment methods do you support?",
    a: "We support M-Pesa (for Kenyan users), Visa/Mastercard, and direct bank transfers. All payments are processed through secure gateways."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = React.useState<number | null>(0);

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-foreground tracking-tight">Frequently Asked Questions</h1>
        <p className="text-foreground/60">Everything you need to know about the Iconoclast Mining Platform.</p>
      </div>

      <div className="space-y-4">
        {FAQS.map((faq, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-card border border-custom rounded-2xl overflow-hidden"
          >
            <button 
              onClick={() => setOpenIndex(openIndex === i ? null : i)}
              className="w-full px-8 py-6 flex items-center justify-between text-left hover:bg-foreground/5 transition-colors"
            >
              <span className="font-bold text-foreground">{faq.q}</span>
              {openIndex === i ? <ChevronUp className="text-orange-500" /> : <ChevronDown className="text-foreground/40" />}
            </button>
            {openIndex === i && (
              <div className="px-8 pb-6 text-foreground/60 leading-relaxed border-t border-custom pt-4">
                {faq.a}
              </div>
            )}
          </motion.div>
        ))}
      </div>

      <div className="bg-orange-500/10 border border-orange-500/20 rounded-3xl p-10 text-center space-y-6">
        <HelpCircle className="w-12 h-12 text-orange-500 mx-auto" />
        <h3 className="text-2xl font-bold text-foreground">Still have questions?</h3>
        <p className="text-foreground/60 max-w-lg mx-auto">
          Our support team is available 24/7 to help you with any technical or financial inquiries.
        </p>
        <button className="bg-orange-500 text-black px-8 py-3 rounded-2xl font-bold hover:scale-105 transition-transform">
          Contact Support
        </button>
      </div>
    </div>
  );
}
