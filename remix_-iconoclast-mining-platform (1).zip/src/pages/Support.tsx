import React from 'react';
import { motion } from 'motion/react';
import { MessageSquare, Mail, Phone, MapPin, Send } from 'lucide-react';

export default function Support() {
  const [formState, setFormState] = React.useState({ name: '', email: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Support ticket submitted! We will get back to you shortly.');
    setFormState({ name: '', email: '', message: '' });
  };

  return (
    <div className="max-w-6xl mx-auto space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-foreground tracking-tight">Support Center</h1>
        <p className="text-foreground/60">We're here to help you scale your mining operation.</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          {[
            { icon: Mail, label: 'Email Us', value: 'support@iconoclast.com', color: 'text-blue-500', bg: 'bg-blue-500/10' },
            { icon: Phone, label: 'Call Us', value: '0717615998', color: 'text-green-500', bg: 'bg-green-500/10' },
            { icon: MapPin, label: 'Visit Us', value: 'Nairobi, Kenya', color: 'text-orange-500', bg: 'bg-orange-500/10' }
          ].map((item, i) => (
            <div key={i} className="bg-card border border-custom p-6 rounded-3xl flex items-center gap-4">
              <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center shrink-0", item.bg)}>
                <item.icon className={cn("w-6 h-6", item.color)} />
              </div>
              <div>
                <p className="text-xs text-foreground/40 uppercase tracking-widest mb-1">{item.label}</p>
                <p className="font-bold text-foreground">{item.value}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="bg-card border border-custom p-10 rounded-[40px] space-y-6">
            <h3 className="text-2xl font-bold text-foreground mb-8">Send us a Message</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs text-foreground/40 uppercase tracking-widest ml-2">Full Name</label>
                <input 
                  type="text" 
                  required
                  value={formState.name}
                  onChange={(e) => setFormState({...formState, name: e.target.value})}
                  placeholder="Allan Mugambi"
                  className="w-full bg-foreground/5 border border-custom rounded-2xl px-6 py-4 text-foreground focus:outline-none focus:border-orange-500 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs text-foreground/40 uppercase tracking-widest ml-2">Email Address</label>
                <input 
                  type="email" 
                  required
                  value={formState.email}
                  onChange={(e) => setFormState({...formState, email: e.target.value})}
                  placeholder="allan@example.com"
                  className="w-full bg-foreground/5 border border-custom rounded-2xl px-6 py-4 text-foreground focus:outline-none focus:border-orange-500 transition-colors"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs text-foreground/40 uppercase tracking-widest ml-2">Message</label>
              <textarea 
                required
                rows={5}
                value={formState.message}
                onChange={(e) => setFormState({...formState, message: e.target.value})}
                placeholder="How can we help you today?"
                className="w-full bg-foreground/5 border border-custom rounded-2xl px-6 py-4 text-foreground focus:outline-none focus:border-orange-500 transition-colors resize-none"
              />
            </div>
            <button 
              type="submit"
              className="w-full bg-orange-500 text-black py-5 rounded-2xl font-bold text-lg flex items-center justify-center gap-3 hover:scale-[1.02] transition-transform shadow-xl shadow-orange-500/20"
            >
              <Send className="w-5 h-5" />
              Submit Ticket
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

import { cn } from '../lib/utils';
