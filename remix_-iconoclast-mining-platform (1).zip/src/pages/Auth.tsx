import React, { useState, useEffect } from 'react';
import { useAuth } from '../lib/AuthContext';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Lock, User, ArrowRight, TrendingUp, Chrome, ShieldCheck, Zap, Globe } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [showForgot, setShowForgot] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { loginEmail, register, login, resetPassword, user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);
    
    try {
      if (showForgot) {
        await resetPassword(email);
        setSuccess('Recovery link sent to your email.');
        setShowForgot(false);
        return;
      }

      if (isLogin) {
        await loginEmail(email, password);
      } else {
        if (password.length < 6) {
          throw new Error('Access Key must be at least 6 characters.');
        }
        await register(email, password, name);
      }
      navigate('/dashboard');
    } catch (err: any) {
      console.error('Auth Error:', err);
      let msg = 'Authentication failed';
      if (err.code === 'auth/wrong-password') msg = 'Invalid Access Key. Please try again.';
      else if (err.code === 'auth/user-not-found') msg = 'No operator found with this email.';
      else if (err.code === 'auth/email-already-in-use') msg = 'This email is already registered.';
      else if (err.code === 'auth/invalid-email') msg = 'Please enter a valid email address.';
      else if (err.code === 'auth/weak-password') msg = 'Access Key must be at least 6 characters.';
      else msg = err.message || msg;
      
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await login();
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Google login failed');
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col lg:flex-row relative overflow-hidden">
      {/* Left Side - Welcome Content */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-center px-20 relative z-10">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-money-orange/10 border border-money-orange/20 text-money-orange text-xs font-black uppercase tracking-widest mb-8">
            <Zap className="w-4 h-4" />
            Institutional Grade Mining
          </div>
          <h1 className="text-7xl font-black leading-[0.9] tracking-tighter mb-8 text-blue-300">
            THE <span className="text-money-orange">GOLDEN</span> <br />
            STANDARD OF <br />
            MINING.
          </h1>
          <p className="text-xl text-blue-400/60 max-w-xl mb-12 leading-relaxed font-medium">
            Join the elite circle of digital asset miners. Iconoclast provides the hardware, security, and infrastructure for your decentralized wealth generation.
          </p>
          
          <div className="grid grid-cols-2 gap-8">
            <div className="space-y-2">
              <div className="w-12 h-12 bg-money-orange/10 rounded-2xl flex items-center justify-center border border-money-orange/20">
                <ShieldCheck className="text-money-orange w-6 h-6" />
              </div>
              <h4 className="font-black text-blue-300 uppercase tracking-widest text-xs">Secure Assets</h4>
              <p className="text-xs text-blue-400/40">Multi-sig protection and cold storage for all mining yields.</p>
            </div>
            <div className="space-y-2">
              <div className="w-12 h-12 bg-money-green/10 rounded-2xl flex items-center justify-center border border-money-green/20">
                <Globe className="text-money-green w-6 h-6" />
              </div>
              <h4 className="font-black text-blue-300 uppercase tracking-widest text-xs">Global Payouts</h4>
              <p className="text-xs text-blue-400/40">Instant M-Pesa and bank withdrawals across the globe.</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Right Side - Auth Form */}
      <div className="flex-1 flex items-center justify-center p-6 relative z-10">
        <div className="absolute inset-0 bg-blue-900/5 backdrop-blur-3xl lg:hidden" />
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative w-full max-w-md"
        >
          <div className="text-center mb-10 lg:hidden">
            <div className="w-16 h-16 bg-linear-to-br from-money-orange to-money-gold rounded-2xl flex items-center justify-center shadow-2xl shadow-money-orange/20 mx-auto mb-6">
              <TrendingUp className="text-black w-10 h-10" />
            </div>
            <h1 className="text-4xl font-black text-blue-300 tracking-tighter mb-2 uppercase">
              Iconoclast
            </h1>
          </div>

          <div className="glass-card p-8 lg:p-12 border-money-orange/20 shadow-2xl shadow-money-orange/5">
            <div className="mb-8">
              <h2 className="text-2xl font-black text-blue-300 uppercase tracking-tighter">
                {showForgot ? 'Reset Access' : isLogin ? 'System Login' : 'Register Terminal'}
              </h2>
              <p className="text-xs text-blue-400/40 font-bold uppercase tracking-widest mt-1">
                {showForgot ? 'Enter your email to recover access' : isLogin ? 'Enter credentials to proceed' : 'Create your mining identity'}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <AnimatePresence mode="wait">
                {!isLogin && !showForgot && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                  >
                    <label className="text-[10px] font-black text-money-orange uppercase tracking-widest mb-2 block">Operator Name</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 text-money-orange/40 w-5 h-5" />
                      <input 
                        type="text" 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="John Doe"
                        className="w-full bg-blue-950/20 border border-money-orange/20 rounded-2xl pl-12 pr-6 py-4 text-blue-300 focus:outline-none focus:border-money-orange transition-all placeholder:text-blue-900"
                        required={!isLogin}
                      />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div>
                <label className="text-[10px] font-black text-money-orange uppercase tracking-widest mb-2 block">Network Email</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-money-orange/40 w-5 h-5" />
                  <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="operator@iconoclast.io"
                    className="w-full bg-blue-950/20 border border-money-orange/20 rounded-2xl pl-12 pr-6 py-4 text-blue-300 focus:outline-none focus:border-money-orange transition-all placeholder:text-blue-900"
                    required
                  />
                </div>
              </div>

              {!showForgot && (
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-[10px] font-black text-money-orange uppercase tracking-widest block">Access Key</label>
                    {isLogin && (
                      <button 
                        type="button"
                        onClick={() => {
                          setShowForgot(true);
                          setError('');
                          setSuccess('');
                        }}
                        className="text-[10px] font-black text-blue-400/40 hover:text-money-orange transition-colors uppercase tracking-widest"
                      >
                        Forgot Key?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-money-orange/40 w-5 h-5" />
                    <input 
                      type="password" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-blue-950/20 border border-money-orange/20 rounded-2xl pl-12 pr-6 py-4 text-blue-300 focus:outline-none focus:border-money-orange transition-all placeholder:text-blue-900"
                      required={!showForgot}
                    />
                  </div>
                  {!isLogin && !showForgot && (
                    <div className="mt-3 space-y-1.5 px-2">
                      <p className="text-[9px] font-black uppercase tracking-widest text-blue-400/40">Security Requirements:</p>
                      <div className="flex flex-wrap gap-x-4 gap-y-1">
                        <div className={cn(
                          "flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wider transition-colors",
                          password.length >= 6 ? "text-money-green" : "text-blue-400/20"
                        )}>
                          <ShieldCheck size={10} /> Min. 6 Characters
                        </div>
                        <div className={cn(
                          "flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wider transition-colors",
                          /[A-Z]/.test(password) ? "text-money-green" : "text-blue-400/20"
                        )}>
                          <ShieldCheck size={10} /> Uppercase Letter
                        </div>
                        <div className={cn(
                          "flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wider transition-colors",
                          /[0-9]/.test(password) ? "text-money-green" : "text-blue-400/20"
                        )}>
                          <ShieldCheck size={10} /> Number
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {error && (
                <p className="text-money-red text-xs font-bold text-center bg-money-red/10 py-2 rounded-lg border border-money-red/20">
                  {error}
                </p>
              )}

              {success && (
                <p className="text-money-green text-xs font-bold text-center bg-money-green/10 py-2 rounded-lg border border-money-green/20">
                  {success}
                </p>
              )}

              <button 
                type="submit"
                disabled={loading}
                className="w-full py-5 rounded-2xl bg-linear-to-br from-money-orange to-money-gold text-black font-black text-lg uppercase tracking-widest shadow-xl shadow-money-orange/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3"
              >
                {loading ? 'Authorizing...' : showForgot ? 'Send Reset Link' : (isLogin ? 'Initiate Login' : 'Register Operator')}
                {!loading && <ArrowRight size={20} />}
              </button>
            </form>

            {!showForgot && (
              <>
                <div className="relative my-8">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-money-orange/10"></div>
                  </div>
                  <div className="relative flex justify-center text-[10px] uppercase font-black tracking-widest">
                    <span className="bg-blue-950/40 px-4 text-blue-400/40">Secure Auth</span>
                  </div>
                </div>

                <button 
                  type="button"
                  onClick={handleGoogleLogin}
                  className="w-full py-4 rounded-2xl bg-blue-900/10 border border-money-orange/10 text-blue-300 font-bold text-sm uppercase tracking-widest hover:bg-blue-900/20 transition-all flex items-center justify-center gap-3"
                >
                  <Chrome size={18} className="text-money-orange" />
                  {isLogin ? 'Sign In with Google' : 'Sign Up with Google'}
                </button>
              </>
            )}

            {showForgot && (
              <button 
                onClick={() => setShowForgot(false)}
                className="w-full mt-6 text-[10px] font-black text-blue-400/40 hover:text-money-orange transition-colors uppercase tracking-widest"
              >
                Back to Login
              </button>
            )}
          </div>

          {!showForgot && (
            <p className="text-center mt-8 text-sm text-blue-400/40 font-medium">
              {isLogin ? "New to the network?" : "Already an operator?"}{' '}
              <button 
                onClick={() => {
                  setIsLogin(!isLogin);
                  setError('');
                  setSuccess('');
                }}
                className="text-money-orange font-black hover:underline uppercase tracking-tighter"
              >
                {isLogin ? 'Register Now' : 'Login Here'}
              </button>
            </p>
          )}
        </motion.div>
      </div>

      {/* Decorative Elements */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-0">
        <div className="absolute top-[-20%] right-[-10%] w-[60%] h-[60%] bg-money-orange/5 blur-[150px] rounded-full" />
        <div className="absolute bottom-[-20%] left-[-10%] w-[60%] h-[60%] bg-blue-900/10 blur-[150px] rounded-full" />
      </div>
    </div>
  );
}
