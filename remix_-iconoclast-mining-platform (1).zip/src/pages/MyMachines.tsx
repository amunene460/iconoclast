import React, { useEffect, useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { collection, query, onSnapshot, doc, updateDoc, increment } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Cpu, Zap, Clock, RefreshCw, AlertCircle, TrendingUp, ShoppingCart } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { Link } from 'react-router-dom';
import { CURRENCY } from '../lib/constants';
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';

export default function MyMachines() {
  const { profile } = useAuth();
  const [machines, setMachines] = useState<any[]>([]);
  const [claiming, setClaiming] = useState<string | null>(null);

  useEffect(() => {
    if (!profile) return;
    const path = `users/${profile.uid}/machines`;
    const q = query(collection(db, path));
    const unsub = onSnapshot(q, (snap) => {
      setMachines(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });
    return () => unsub();
  }, [profile]);

  const handleClaim = async (machine: any) => {
    if (!profile) return;
    
    // Check if 24h passed
    const lastClaimed = new Date(machine.lastClaimedAt).getTime();
    const now = new Date().getTime();
    const diffHours = (now - lastClaimed) / (1000 * 60 * 60);

    if (diffHours < 24) {
      alert(`Rewards available in ${Math.ceil(24 - diffHours)} hours.`);
      return;
    }

    setClaiming(machine.id);
    try {
      const userRef = doc(db, 'users', profile.uid);
      const machineRef = doc(db, `users/${profile.uid}/machines`, machine.id);

      await updateDoc(userRef, {
        balance: increment(machine.dailyIncome)
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `users/${profile.uid}`));

      await updateDoc(machineRef, {
        lastClaimedAt: new Date().toISOString(),
        totalEarned: increment(machine.dailyIncome)
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `users/${profile.uid}/machines/${machine.id}`));

      // Update global stats
      const statsRef = doc(db, 'system', 'stats');
      await updateDoc(statsRef, {
        totalProfit: increment(machine.dailyIncome)
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, 'system/stats'));

      alert(`Claimed ${CURRENCY} ${machine.dailyIncome} rewards!`);
    } catch (error) {
      console.error('Claim failed:', error);
    } finally {
      setClaiming(null);
    }
  };

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-foreground tracking-tighter">Active <span className="text-money-orange">Rigs</span></h1>
          <p className="text-foreground/40 font-medium">Monitor and manage your deployed mining hardware.</p>
        </div>
        <div className="bg-money-green/10 border border-money-green/20 px-6 py-3 rounded-2xl flex items-center gap-4">
          <div className="text-right">
            <p className="text-[10px] font-black text-foreground/30 uppercase tracking-widest">Est. Weekly Return</p>
            <p className="text-2xl font-black text-money-green">
              {CURRENCY} {(machines.reduce((acc, m) => acc + m.dailyIncome, 0) * 7).toFixed(2)}
            </p>
          </div>
          <div className="w-10 h-10 bg-money-green/20 rounded-xl flex items-center justify-center">
            <TrendingUp className="text-money-green w-6 h-6" />
          </div>
        </div>
      </div>

      {machines.length === 0 ? (
        <div className="glass-card p-20 flex flex-col items-center justify-center text-center">
          <div className="w-24 h-24 bg-foreground/5 rounded-[32px] flex items-center justify-center mb-8 border border-custom">
            <Cpu className="text-foreground/20 w-12 h-12" />
          </div>
          <h3 className="text-2xl font-black text-foreground mb-4">No Active Rigs Found</h3>
          <p className="text-foreground/40 max-w-sm mb-10 text-lg">You haven't purchased any mining machines yet. Visit the marketplace to start your journey.</p>
          <Link to="/marketplace" className="btn-primary flex items-center gap-3 px-10">
            <ShoppingCart size={24} />
            Go to Marketplace
          </Link>
        </div>
      ) : (
        <div className="space-y-6">
          {machines.map((machine, i) => {
            const lastClaimed = new Date(machine.lastClaimedAt).getTime();
            const now = new Date().getTime();
            const diffHours = (now - lastClaimed) / (1000 * 60 * 60);
            const canClaim = diffHours >= 24;

            return (
              <motion.div 
                key={machine.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                className="glass-card overflow-hidden flex flex-col lg:flex-row gap-8 items-center group"
              >
                <div className="w-full lg:w-48 h-48 lg:h-full shrink-0 relative overflow-hidden">
                  <img 
                    src={machine.imageUrl || 'https://images.unsplash.com/photo-1591488320449-011701bb6704?auto=format&fit=crop&q=80&w=1000'} 
                    alt={machine.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-linear-to-t from-background via-transparent to-transparent opacity-60" />
                </div>
                
                <div className="flex-1 w-full p-4 lg:p-8 lg:pl-0 space-y-4 lg:space-y-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-lg lg:text-2xl font-black text-white tracking-tight">{machine.name}</h3>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-[8px] lg:text-[10px] font-black text-foreground/30 uppercase tracking-widest">ID: {machine.id.slice(0, 8)}</span>
                        <span className="w-1 h-1 bg-foreground/20 rounded-full" />
                        <span className="flex items-center gap-1.5 text-[8px] lg:text-[10px] font-black text-money-blue uppercase tracking-widest">
                          <Zap size={10} className="lg:w-3 lg:h-3" /> {machine.hashrate || 'N/A'}
                        </span>
                      </div>
                    </div>
                    <div className={cn(
                      "px-3 lg:px-4 py-1 lg:py-1.5 rounded-full text-[8px] lg:text-[10px] font-black uppercase tracking-widest border",
                      machine.status === 'active' ? "bg-money-green/10 text-money-green border-money-green/20" : "bg-money-gold/10 text-money-gold border-money-gold/20"
                    )}>
                      {machine.status}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 lg:gap-8 pt-4 lg:pt-6 border-t border-white/5">
                    <div>
                      <p className="text-[8px] lg:text-[10px] font-black text-foreground/30 uppercase tracking-widest mb-1">Daily Yield</p>
                      <p className="text-sm lg:text-xl font-black text-money-orange">{CURRENCY} {machine.dailyIncome.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-[8px] lg:text-[10px] font-black text-foreground/30 uppercase tracking-widest mb-1">Total Earned</p>
                      <p className="text-sm lg:text-xl font-black text-money-green">{CURRENCY} {(machine.totalEarned || 0).toFixed(2)}</p>
                    </div>
                    <div className="hidden md:block">
                      <p className="text-[8px] lg:text-[10px] font-black text-foreground/30 uppercase tracking-widest mb-1">Power Usage</p>
                      <p className="text-sm lg:text-xl font-black text-foreground/60">{machine.power || 'N/A'}</p>
                    </div>
                  </div>
                </div>

                <div className="p-4 lg:p-8 lg:pr-10 w-full lg:w-auto">
                  <button 
                    onClick={() => handleClaim(machine)}
                    disabled={!canClaim || claiming === machine.id}
                    className={cn(
                      "w-full lg:w-auto px-6 lg:px-10 py-3 lg:py-5 rounded-xl lg:rounded-2xl font-black transition-all duration-300 shrink-0 text-sm lg:text-lg uppercase tracking-widest",
                      canClaim 
                        ? "bg-linear-to-br from-money-orange to-money-gold text-black shadow-lg shadow-money-orange/20 hover:scale-[1.02] active:scale-95" 
                        : "bg-foreground/5 text-foreground/20 cursor-not-allowed border border-white/5"
                    )}
                  >
                    {claiming === machine.id ? (
                      <RefreshCw className="w-5 h-5 lg:w-6 lg:h-6 animate-spin mx-auto" />
                    ) : canClaim ? (
                      'Claim Rewards'
                    ) : (
                      `${Math.ceil(24 - diffHours)}h Left`
                    )}
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
