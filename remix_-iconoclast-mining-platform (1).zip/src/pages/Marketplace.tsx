import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext';
import { MACHINES, CURRENCY } from '../lib/constants';
import { ShoppingCart, Zap, Cpu, ShieldCheck, Info, X, CheckCircle2, AlertCircle, Package } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { doc, setDoc, updateDoc, increment, collection, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { cn } from '../lib/utils';
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';

export default function Marketplace() {
  const { profile } = useAuth();
  const [purchasing, setPurchasing] = useState<string | null>(null);
  const [selectedMachine, setSelectedMachine] = useState<any | null>(null);
  const [showSuccess, setShowSuccess] = useState<string | null>(null);

  const handlePurchase = async (machine: any) => {
    if (!profile) return;
    if (profile.balance < machine.price) return;

    setPurchasing(machine.id);
    try {
      // 1. Deduct balance
      const userRef = doc(db, 'users', profile.uid);
      await updateDoc(userRef, {
        balance: increment(-machine.price)
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `users/${profile.uid}`));

      // 2. Add machine to user's collection
      const userMachinesRef = collection(db, `users/${profile.uid}/machines`);
      await addDoc(userMachinesRef, {
        machineId: machine.id,
        name: machine.name,
        dailyIncome: machine.dailyIncome,
        purchaseDate: new Date().toISOString(),
        lastClaimedAt: new Date().toISOString(),
        status: 'active',
        imageUrl: machine.imageUrl,
        hashrate: machine.stats.hashrate,
        power: machine.stats.power,
        totalEarned: 0
      }).catch(err => handleFirestoreError(err, OperationType.CREATE, `users/${profile.uid}/machines`));

      // 3. Log transaction
      const txRef = collection(db, `users/${profile.uid}/transactions`);
      await addDoc(txRef, {
        type: 'purchase',
        amount: machine.price,
        currency: CURRENCY,
        status: 'completed',
        timestamp: new Date().toISOString(),
        details: `Purchased ${machine.name}`
      }).catch(err => handleFirestoreError(err, OperationType.CREATE, `users/${profile.uid}/transactions`));

      // 4. Update global stats
      const statsRef = doc(db, 'system', 'stats');
      await updateDoc(statsRef, {
        totalProfit: increment(machine.price)
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, 'system/stats'));

      setShowSuccess(machine.name);
      setSelectedMachine(null);
      setTimeout(() => setShowSuccess(null), 5000);
    } catch (error) {
      console.error('Purchase failed:', error);
    } finally {
      setPurchasing(null);
    }
  };

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tighter">
            HARDWARE <span className="text-money-orange">MARKETPLACE</span>
          </h1>
          <p className="text-gray-500 font-medium">Acquire high-performance ASIC and GPU hardware to scale your decentralized wealth.</p>
        </div>
        <div className="bg-money-orange/10 border border-money-orange/20 px-6 py-4 rounded-3xl flex items-center gap-4 shadow-lg shadow-money-orange/5">
          <div className="w-10 h-10 bg-money-orange rounded-full flex items-center justify-center">
            <Zap className="text-black w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] text-money-orange font-black uppercase tracking-widest">Average ROI</p>
            <p className="text-xl font-black text-white">5.3% <span className="text-sm text-money-green">Daily</span></p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 lg:gap-8">
        {MACHINES.map((machine, i) => {
          const dailyROI = ((machine.dailyIncome / machine.price) * 100).toFixed(1);
          const monthlyIncome = machine.dailyIncome * 30;
          const monthlyROI = ((monthlyIncome / machine.price) * 100).toFixed(0);

          return (
            <motion.div 
              key={machine.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="glass-card group relative overflow-hidden flex flex-col h-full"
            >
              <div className="absolute top-0 left-0 w-full h-1.5 bg-linear-to-r from-money-orange to-money-gold scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left z-10" />
              
              <div className="relative h-56 overflow-hidden">
                <img 
                  src={machine.imageUrl} 
                  alt={machine.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-linear-to-t from-background via-transparent to-transparent opacity-80" />
                <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-xl px-4 py-1.5 rounded-full border border-white/10 text-[10px] font-black uppercase tracking-[0.2em] text-money-orange shadow-2xl">
                  {machine.category}
                </div>
                <div className="absolute bottom-4 left-6">
                  <h3 className="text-2xl font-black tracking-tighter text-white">{machine.name}</h3>
                </div>
              </div>

              <div className="p-4 lg:p-8 flex-1 flex flex-col">
                <div className="flex justify-between items-end mb-6 lg:mb-8">
                  <div>
                    <p className="text-[8px] lg:text-[10px] text-foreground/40 uppercase tracking-widest font-black mb-1">Unit Price</p>
                    <p className="text-2xl lg:text-4xl font-black text-white tracking-tighter">{CURRENCY} {machine.price.toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <div className="bg-money-gold/10 px-2 lg:px-3 py-1 rounded-lg border border-money-gold/20 inline-block mb-1">
                      <p className="text-[10px] lg:text-xs font-black text-money-gold">{machine.stock} Left</p>
                    </div>
                    <p className="text-[8px] lg:text-[10px] text-foreground/40 uppercase tracking-widest font-bold">Stock</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 lg:gap-4 mb-6 lg:mb-8">
                  <div className="bg-foreground/5 p-3 lg:p-4 rounded-xl lg:rounded-2xl border border-custom group-hover:border-money-orange/20 transition-all duration-300">
                    <p className="text-[8px] lg:text-[10px] text-foreground/40 uppercase tracking-widest font-black mb-1">Daily Profit</p>
                    <p className="text-lg lg:text-2xl font-black text-money-green">+{CURRENCY} {machine.dailyIncome}</p>
                  </div>
                  <div className="bg-foreground/5 p-3 lg:p-4 rounded-xl lg:rounded-2xl border border-custom group-hover:border-money-blue/20 transition-all duration-300">
                    <p className="text-[8px] lg:text-[10px] text-foreground/40 uppercase tracking-widest font-black mb-1">Monthly Profit</p>
                    <p className="text-lg lg:text-2xl font-black text-money-gold">+{CURRENCY} {monthlyIncome}</p>
                  </div>
                </div>

                <div className="space-y-3 mb-8">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-foreground/40 font-medium">Hashrate</span>
                    <span className="text-money-blue font-black">{machine.stats.hashrate}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-foreground/40 font-medium">Power Consumption</span>
                    <span className="text-foreground/60 font-bold">{machine.stats.power}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-foreground/40 font-medium">Monthly ROI</span>
                    <span className="text-money-green font-black">{monthlyROI}%</span>
                  </div>
                </div>

                <button 
                  onClick={() => setSelectedMachine(machine)}
                  className="w-full mt-auto py-5 rounded-2xl font-black flex items-center justify-center gap-3 transition-all duration-300 shadow-2xl text-lg uppercase tracking-widest bg-linear-to-br from-money-orange to-money-gold text-black hover:scale-[1.02] active:scale-95 shadow-money-orange/20"
                >
                  <ShoppingCart className="w-6 h-6" />
                  Purchase Rig
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Purchase Confirmation Modal */}
      <AnimatePresence>
        {selectedMachine && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => !purchasing && setSelectedMachine(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-background border border-white/10 rounded-[40px] overflow-hidden shadow-2xl"
            >
              <div className="relative h-48">
                <img 
                  src={selectedMachine.imageUrl} 
                  alt={selectedMachine.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-linear-to-t from-background to-transparent" />
                <button 
                  onClick={() => setSelectedMachine(null)}
                  disabled={purchasing === selectedMachine.id}
                  className="absolute top-6 right-6 w-10 h-10 bg-black/50 backdrop-blur-xl rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="p-10 space-y-8">
                <div>
                  <h3 className="text-3xl font-black text-white tracking-tighter mb-2">Confirm Purchase</h3>
                  <p className="text-foreground/60 font-medium">You are about to acquire the {selectedMachine.name}.</p>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center p-6 bg-foreground/5 rounded-2xl border border-white/5">
                    <span className="text-foreground/40 font-black uppercase tracking-widest text-xs">Total Cost</span>
                    <span className="text-3xl font-black text-money-orange">{CURRENCY} {selectedMachine.price.toLocaleString()}</span>
                  </div>
                  
                  {!profile ? (
                    <div className="flex items-center gap-3 p-4 bg-money-orange/10 border border-money-orange/20 rounded-xl text-money-orange">
                      <AlertCircle size={20} />
                      <p className="text-xs font-bold">
                        Please <Link to="/auth" className="underline font-black">sign in</Link> to complete this purchase.
                      </p>
                    </div>
                  ) : profile.balance < selectedMachine.price ? (
                    <div className="flex items-center gap-3 p-4 bg-money-red/10 border border-money-red/20 rounded-xl text-money-red">
                      <AlertCircle size={20} />
                      <p className="text-xs font-bold">Insufficient balance. Your current balance is {CURRENCY} {profile.balance.toLocaleString()}.</p>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3 p-4 bg-money-green/10 border border-money-green/20 rounded-xl text-money-green">
                      <CheckCircle2 size={20} />
                      <p className="text-xs font-bold">Funds available. Transaction ready.</p>
                    </div>
                  )}
                </div>

                <div className="flex gap-4">
                  <button 
                    onClick={() => setSelectedMachine(null)}
                    disabled={purchasing === selectedMachine.id}
                    className="flex-1 py-5 rounded-2xl font-black text-foreground/40 uppercase tracking-widest hover:bg-foreground/5 transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={() => handlePurchase(selectedMachine)}
                    disabled={!profile || profile.balance < selectedMachine.price || purchasing === selectedMachine.id}
                    className="flex-[2] py-5 rounded-2xl bg-linear-to-br from-money-orange to-money-gold text-black font-black text-lg uppercase tracking-widest shadow-xl shadow-money-orange/20 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 disabled:hover:scale-100"
                  >
                    {purchasing === selectedMachine.id ? 'Processing...' : 'Confirm & Buy'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Success Notification */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 z-50 bg-money-green text-black px-8 py-4 rounded-2xl font-black shadow-2xl flex items-center gap-4"
          >
            <CheckCircle2 size={24} />
            <div>
              <p className="uppercase tracking-widest text-[10px]">Purchase Successful</p>
              <p className="text-lg tracking-tighter">{showSuccess} added to your rigs</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
