import React, { useEffect, useState } from 'react';
import { useAuth } from '../lib/AuthContext';
import { db } from '../lib/firebase';
import { doc, onSnapshot, updateDoc, collection, query, getDocs, setDoc, increment } from 'firebase/firestore';
import { 
  Shield, 
  Users, 
  TrendingUp, 
  DollarSign, 
  AlertTriangle, 
  Activity,
  Package,
  Power,
  RefreshCw
} from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { CURRENCY, MACHINES } from '../lib/constants';
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';

export default function Admin() {
  const { profile } = useAuth();
  const [stats, setStats] = useState<any>(null);
  const [investorCount, setInvestorCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile?.role !== 'admin') return;

    // Listen to global stats
    const statsRef = doc(db, 'system', 'stats');
    const unsubStats = onSnapshot(statsRef, (docSnap) => {
      if (docSnap.exists()) {
        setStats(docSnap.data());
      } else {
        // Initialize stats if they don't exist
        const initialStats = {
          totalInvestors: 0,
          totalDeposits: 0,
          totalWithdrawals: 0,
          totalProfit: 0,
          siteVisits: 0,
          isMaintenanceMode: false
        };
        setDoc(statsRef, initialStats);
        setStats(initialStats);
      }
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'system/stats');
    });

    // Get investor count
    const usersRef = collection(db, 'users');
    getDocs(usersRef).then(snap => {
      setInvestorCount(snap.size);
    });

    return () => unsubStats();
  }, [profile]);

  const toggleMaintenance = async () => {
    if (!stats) return;
    const statsRef = doc(db, 'system', 'stats');
    await updateDoc(statsRef, {
      isMaintenanceMode: !stats.isMaintenanceMode
    }).catch(err => handleFirestoreError(err, OperationType.UPDATE, 'system/stats'));
  };

  const handleCashOut = async () => {
    if (!stats || stats.totalProfit <= 0) return;
    if (!confirm(`Are you sure you want to cash out ${CURRENCY} ${stats.totalProfit.toLocaleString()}?`)) return;

    const statsRef = doc(db, 'system', 'stats');
    await updateDoc(statsRef, {
      totalProfit: 0,
      totalWithdrawals: increment(stats.totalProfit)
    }).catch(err => handleFirestoreError(err, OperationType.UPDATE, 'system/stats'));
    
    alert('Cash out successful! Funds have been moved to your account.');
  };

  if (profile?.role !== 'admin') {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center">
        <Shield size={64} className="text-money-red mb-6 opacity-20" />
        <h2 className="text-3xl font-black text-white tracking-tighter mb-2">ACCESS DENIED</h2>
        <p className="text-foreground/40 font-medium">This terminal is restricted to authorized personnel only.</p>
      </div>
    );
  }

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-white tracking-tighter">
            ADMIN <span className="text-money-orange">TERMINAL</span>
          </h1>
          <p className="text-foreground/40 font-medium">Global platform oversight and system control.</p>
        </div>
        <button 
          onClick={toggleMaintenance}
          className={cn(
            "flex items-center gap-3 px-8 py-4 rounded-2xl font-black transition-all duration-300 shadow-xl",
            stats?.isMaintenanceMode 
              ? "bg-money-red text-white shadow-money-red/20" 
              : "bg-money-green text-black shadow-money-green/20"
          )}
        >
          <Power size={20} />
          {stats?.isMaintenanceMode ? 'SYSTEM OFFLINE' : 'SYSTEM ONLINE'}
        </button>
      </div>

      {/* Primary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          icon={<Users className="text-money-blue" />}
          label="Total Investors"
          value={investorCount.toLocaleString()}
          color="blue"
        />
        <StatCard 
          icon={<DollarSign className="text-money-green" />}
          label="Total Deposits"
          value={`${CURRENCY} ${(stats?.totalDeposits || 0).toLocaleString()}`}
          color="green"
        />
        <StatCard 
          icon={<TrendingUp className="text-money-orange" />}
          label="Total Profit Generated"
          value={`${CURRENCY} ${(stats?.totalProfit || 0).toLocaleString()}`}
          color="orange"
          action={
            <button 
              onClick={handleCashOut}
              className="mt-2 text-[10px] font-black text-money-orange bg-money-orange/10 px-3 py-1 rounded-lg hover:bg-money-orange hover:text-black transition-all"
            >
              CASH OUT
            </button>
          }
        />
        <StatCard 
          icon={<Activity className="text-money-gold" />}
          label="Platform Visits"
          value={(stats?.siteVisits || 0).toLocaleString()}
          color="gold"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-10">
        {/* Machine Inventory */}
        <div className="lg:col-span-2 glass-card p-10">
          <h3 className="text-2xl font-black text-white mb-8 flex items-center gap-4">
            <Package className="text-money-orange" />
            Hardware Inventory
          </h3>
          <div className="space-y-4">
            {MACHINES.map((machine) => (
              <div key={machine.id} className="flex items-center justify-between p-6 bg-foreground/5 border border-white/5 rounded-2xl">
                <div className="flex items-center gap-4">
                  <img src={machine.imageUrl} className="w-12 h-12 rounded-xl object-cover" alt="" referrerPolicy="no-referrer" />
                  <div>
                    <p className="font-black text-white">{machine.name}</p>
                    <p className="text-[10px] text-foreground/40 uppercase tracking-widest font-bold">{machine.category}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xl font-black text-money-orange">{machine.stock} Left</p>
                  <p className="text-[10px] text-foreground/40 uppercase tracking-widest font-bold">Current Stock</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* System Alerts */}
        <div className="space-y-6">
          <div className="glass-card p-8 border-money-red/20">
            <h4 className="text-lg font-black text-money-red mb-4 flex items-center gap-3">
              <AlertTriangle size={20} />
              Critical Actions
            </h4>
            <p className="text-sm text-foreground/60 mb-6 leading-relaxed">
              Use the kill switch to halt all mining operations and deposits immediately if suspicious activity is detected.
            </p>
            <button 
              onClick={() => alert('Emergency withdrawal initiated. All funds are being secured.')}
              className="w-full py-4 bg-money-red/10 border border-money-red/20 text-money-red rounded-2xl font-black hover:bg-money-red hover:text-white transition-all"
            >
              EMERGENCY KILL SWITCH
            </button>
          </div>

          <div className="glass-card p-8">
            <h4 className="text-lg font-black text-money-blue mb-4 flex items-center gap-3">
              <RefreshCw size={20} />
              Market Status
            </h4>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-foreground/40">Network Difficulty</span>
                <span className="text-sm font-black text-money-green">LOW</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-foreground/40">Global Hashrate</span>
                <span className="text-sm font-black text-money-blue">452.1 EH/s</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-foreground/40">Profit Margin</span>
                <span className="text-sm font-black text-money-gold">HIGH</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, color, action }: { icon: React.ReactNode, label: string, value: string, color: string, action?: React.ReactNode }) {
  return (
    <div className="glass-card p-8 flex flex-col gap-4">
      <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center", {
        "bg-money-blue/10": color === 'blue',
        "bg-money-green/10": color === 'green',
        "bg-money-orange/10": color === 'orange',
        "bg-money-gold/10": color === 'gold',
      })}>
        {icon}
      </div>
      <div>
        <p className="text-[10px] text-foreground/40 uppercase tracking-[0.2em] font-black mb-1">{label}</p>
        <p className="text-2xl font-black text-white tracking-tight">{value}</p>
        {action}
      </div>
    </div>
  );
}
