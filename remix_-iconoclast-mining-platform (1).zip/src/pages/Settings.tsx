import React from 'react';
import { useAuth } from '../lib/AuthContext';
import { Settings as SettingsIcon, User, Bell, Shield, Wallet, CreditCard } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Settings() {
  const { profile } = useAuth();

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      <div>
        <h1 className="text-3xl font-bold text-foreground tracking-tight">Account Settings</h1>
        <p className="text-foreground/60">Manage your profile and platform preferences.</p>
      </div>

      <div className="grid md:grid-cols-4 gap-8">
        <nav className="space-y-2">
          {[
            { icon: User, label: 'Profile', active: true },
            { icon: Bell, label: 'Notifications', active: false },
            { icon: Shield, label: 'Security', active: false },
            { icon: Wallet, label: 'Payouts', active: false },
            { icon: CreditCard, label: 'Billing', active: false }
          ].map((item, i) => (
            <button 
              key={i}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all",
                item.active ? "bg-orange-500 text-black" : "text-foreground/60 hover:bg-foreground/5 hover:text-foreground"
              )}
            >
              <item.icon size={18} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="md:col-span-3 space-y-8">
          <div className="bg-card border border-custom rounded-[32px] p-8 space-y-8">
            <div className="flex items-center gap-6">
              <div className="w-20 h-20 bg-orange-500 rounded-full flex items-center justify-center text-3xl font-bold text-black">
                {profile?.displayName?.charAt(0)}
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground">{profile?.displayName}</h3>
                <p className="text-foreground/40 text-sm">{profile?.email}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-8 border-t border-custom">
              <div className="space-y-2">
                <label className="text-xs text-foreground/40 uppercase tracking-widest ml-2">Display Name</label>
                <input 
                  type="text" 
                  defaultValue={profile?.displayName}
                  className="w-full bg-foreground/5 border border-custom rounded-2xl px-6 py-4 text-foreground focus:outline-none focus:border-orange-500 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs text-foreground/40 uppercase tracking-widest ml-2">Email Address</label>
                <input 
                  type="email" 
                  defaultValue={profile?.email}
                  disabled
                  className="w-full bg-foreground/5 border border-custom rounded-2xl px-6 py-4 text-foreground/40 cursor-not-allowed"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs text-foreground/40 uppercase tracking-widest ml-2">Phone Number</label>
                <input 
                  type="text" 
                  placeholder="0717615998"
                  className="w-full bg-foreground/5 border border-custom rounded-2xl px-6 py-4 text-foreground focus:outline-none focus:border-orange-500 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs text-foreground/40 uppercase tracking-widest ml-2">Bank Account / Paybill</label>
                <input 
                  type="text" 
                  placeholder="Enter withdrawal details"
                  className="w-full bg-foreground/5 border border-custom rounded-2xl px-6 py-4 text-foreground focus:outline-none focus:border-orange-500 transition-colors"
                />
              </div>
            </div>

            <div className="pt-8 border-t border-custom flex justify-end">
              <button className="bg-white text-black px-8 py-3 rounded-2xl font-bold hover:bg-orange-500 transition-colors">
                Save Changes
              </button>
            </div>
          </div>

          <div className="bg-red-500/5 border border-red-500/20 rounded-[32px] p-8">
            <h4 className="text-red-500 font-bold mb-2">Danger Zone</h4>
            <p className="text-sm text-foreground/40 mb-6">Once you delete your account, there is no going back. Please be certain.</p>
            <button className="text-red-500 border border-red-500/20 px-6 py-3 rounded-2xl text-sm font-bold hover:bg-red-500 hover:text-white transition-all">
              Delete Account
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
