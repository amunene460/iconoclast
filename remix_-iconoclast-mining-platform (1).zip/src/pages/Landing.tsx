import React from 'react';
import { useAuth } from '../lib/AuthContext';
import { Link, Navigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { TrendingUp, Shield, Zap, Globe, ArrowRight } from 'lucide-react';

export default function Landing() {
  const { user, loading } = useAuth();

  if (loading) return null;
  if (user) return <Navigate to="/dashboard" />;

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white overflow-hidden selection:bg-orange-500/30">
      {/* Background Glows */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-orange-500/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-500/10 blur-[120px] rounded-full" />
      </div>

      {/* Nav */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-8 max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
            <TrendingUp className="text-black w-6 h-6" />
          </div>
          <span className="font-bold text-2xl tracking-tight">ICONOCLAST</span>
        </div>
        <Link 
          to="/auth"
          className="bg-white text-black px-6 py-2.5 rounded-full font-semibold hover:bg-orange-500 transition-colors duration-300"
        >
          Get Started
        </Link>
      </nav>

      {/* Hero */}
      <main className="relative z-10 max-w-7xl mx-auto px-6 pt-20 pb-32">
        <div className="grid lg:grid-template-columns: 1.2fr 1fr gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-500 text-sm font-medium mb-6">
              <Zap className="w-4 h-4" />
              Next-Gen Mining Infrastructure
            </div>
            <h1 className="text-6xl lg:text-8xl font-bold leading-[0.9] tracking-tight mb-8">
              MINE THE <br />
              <span className="text-orange-500">FUTURE</span> OF <br />
              WEALTH.
            </h1>
            <p className="text-xl text-gray-400 max-w-xl mb-10 leading-relaxed">
              Iconoclast Mining Platform provides high-performance tech machines that generate passive crypto income. Secure, transparent, and scalable.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link 
                to="/auth"
                className="bg-orange-500 text-black px-8 py-4 rounded-2xl font-bold text-lg flex items-center gap-3 hover:scale-105 transition-transform duration-300 shadow-xl shadow-orange-500/20"
              >
                Start Mining Now
                <ArrowRight className="w-5 h-5" />
              </Link>
              <div className="flex items-center gap-4 px-6 py-4 rounded-2xl bg-white/5 border border-white/10">
                <div className="flex -space-x-3">
                  {[1,2,3].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-[#0a0a0a] bg-gray-800 flex items-center justify-center text-[10px]">
                      U{i}
                    </div>
                  ))}
                </div>
                <span className="text-sm text-gray-400 font-medium">10k+ Active Miners</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-square bg-gradient-to-br from-orange-500/20 to-blue-500/20 rounded-[40px] border border-white/10 p-8 relative overflow-hidden group">
              <div className="absolute inset-0 bg-grid-white/[0.02] bg-[size:40px_40px]" />
              <div className="relative z-10 h-full flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <div className="p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10">
                    <p className="text-xs text-gray-500 uppercase tracking-widest mb-1">Hash Rate</p>
                    <p className="text-2xl font-bold">142.5 TH/s</p>
                  </div>
                  <div className="p-4 bg-black/40 backdrop-blur-md rounded-2xl border border-white/10">
                    <p className="text-xs text-gray-500 uppercase tracking-widest mb-1">Efficiency</p>
                    <p className="text-2xl font-bold text-green-400">99.9%</p>
                  </div>
                </div>
                <div className="w-full h-48 bg-black/40 backdrop-blur-md rounded-3xl border border-white/10 flex items-end p-6 gap-2">
                  {[40, 70, 45, 90, 65, 80, 55, 95, 75, 85].map((h, i) => (
                    <motion.div 
                      key={i}
                      initial={{ height: 0 }}
                      animate={{ height: `${h}%` }}
                      transition={{ duration: 1, delay: i * 0.1 }}
                      className="flex-1 bg-orange-500/40 rounded-t-lg border-t border-orange-500"
                    />
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      {/* Features */}
      <section className="relative z-10 px-6 py-24 bg-white/[0.02] border-y border-white/5">
        <div className="max-w-7xl mx-auto grid md:grid-template-columns: repeat(3, 1fr) gap-12">
          {[
            { icon: Shield, title: 'Military-Grade Security', desc: 'Your assets are protected by advanced encryption and multi-sig protocols.' },
            { icon: Globe, title: 'Global Accessibility', desc: 'Withdraw to bank accounts or mobile money (M-Pesa) anywhere in the world.' },
            { icon: Zap, title: 'Instant Payouts', desc: 'Claim your mining rewards daily and withdraw at the end of every week.' }
          ].map((f, i) => (
            <div key={i} className="group">
              <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-orange-500 transition-colors duration-300">
                <f.icon className="w-7 h-7 group-hover:text-black transition-colors duration-300" />
              </div>
              <h3 className="text-xl font-bold mb-4">{f.title}</h3>
              <p className="text-gray-400 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
