import React, { useState, useEffect } from 'react';
import { useAuth } from '../lib/AuthContext';
import { 
  Wallet as WalletIcon, 
  ArrowUpCircle, 
  ArrowDownCircle, 
  CreditCard, 
  Smartphone,
  History,
  CheckCircle2,
  Clock,
  XCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { collection, query, orderBy, onSnapshot, addDoc, doc, updateDoc, increment } from 'firebase/firestore';
import { db } from '../lib/firebase';

import { CURRENCY } from '../lib/constants';

import { handleFirestoreError, OperationType } from '../lib/errorHandlers';

export default function Wallet() {
  const { profile } = useAuth();
  const [transactions, setTransactions] = useState<any[]>([]);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<'mpesa' | 'visa'>('mpesa');
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    if (!profile) return;
    const path = `users/${profile.uid}/transactions`;
    const q = query(
      collection(db, path),
      orderBy('timestamp', 'desc')
    );
    const unsub = onSnapshot(q, (snap) => {
      setTransactions(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });
    return () => unsub();
  }, [profile]);

  const [step, setStep] = useState<'input' | 'processing' | 'success' | 'failed'>('input');
  const [phone, setPhone] = useState('0717615998');

  const handleDeposit = async () => {
    if (!profile || !amount || isNaN(Number(amount))) return;
    
    setStep('processing');
    setProcessing(true);
    try {
      // Real-world M-Pesa STK Push simulation
      const response = await fetch('/api/payments/stk-push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber: phone, amount: Number(amount) })
      });

      if (!response.ok) throw new Error('STK Push failed');

      // Simulate waiting for user to enter PIN
      await new Promise(resolve => setTimeout(resolve, 5000));

      const txRef = collection(db, `users/${profile.uid}/transactions`);
      await addDoc(txRef, {
        type: 'deposit',
        amount: Number(amount),
        currency: CURRENCY,
        method: method,
        status: 'completed',
        timestamp: new Date().toISOString(),
        details: `Deposit via ${method.toUpperCase()} (${phone})`
      }).catch(err => handleFirestoreError(err, OperationType.CREATE, `users/${profile.uid}/transactions`));

      const userRef = doc(db, 'users', profile.uid);
      await updateDoc(userRef, {
        balance: increment(Number(amount))
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, `users/${profile.uid}`));

      const statsRef = doc(db, 'system', 'stats');
      await updateDoc(statsRef, {
        totalDeposits: increment(Number(amount))
      }).catch(err => handleFirestoreError(err, OperationType.UPDATE, 'system/stats'));

      setStep('success');
      setAmount('');
    } catch (error) {
      console.error('Deposit failed:', error);
      setStep('failed');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="space-y-10">
      <div className="grid lg:grid-cols-2 gap-10">
        {/* Deposit Section */}
        <div className="space-y-8">
          <div className="glass-card p-10 border-money-orange/20">
            <h3 className="text-2xl font-black text-blue-300 mb-8 flex items-center gap-4 uppercase tracking-tighter">
              <div className="p-2 bg-money-green/10 rounded-xl">
                <ArrowUpCircle className="text-money-green w-6 h-6" />
              </div>
              Capital Injection
            </h3>
            
            <AnimatePresence mode="wait">
              {step === 'input' && (
                <motion.div 
                  key="input"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-6"
                >
                  <div>
                    <label className="text-[10px] font-black text-money-orange uppercase tracking-[0.2em] mb-3 block">Deposit Amount ({CURRENCY})</label>
                    <div className="relative">
                      <span className="absolute left-6 top-1/2 -translate-y-1/2 text-2xl font-black text-money-orange">{CURRENCY}</span>
                      <input 
                        type="number" 
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        placeholder="0.00"
                        className="w-full bg-blue-950/20 border border-money-orange/20 rounded-2xl pl-16 pr-6 py-5 text-blue-300 font-black text-3xl focus:outline-none focus:border-money-orange transition-all"
                      />
                    </div>
                  </div>

                  {method === 'mpesa' && (
                    <div>
                      <label className="text-[10px] font-black text-money-orange uppercase tracking-[0.2em] mb-3 block">M-Pesa Registered Number</label>
                      <div className="relative">
                        <Smartphone className="absolute left-6 top-1/2 -translate-y-1/2 text-money-orange/40 w-6 h-6" />
                        <input 
                          type="tel" 
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="07XXXXXXXX"
                          className="w-full bg-blue-950/20 border border-money-orange/20 rounded-2xl pl-16 pr-6 py-5 text-blue-300 font-black text-xl focus:outline-none focus:border-money-orange transition-all"
                        />
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <button 
                      onClick={() => setMethod('mpesa')}
                      className={cn(
                        "flex flex-col items-center gap-3 p-6 rounded-2xl border transition-all group",
                        method === 'mpesa' ? "bg-money-orange/10 border-money-orange text-money-orange" : "bg-blue-950/20 border-money-orange/10 text-blue-400/40"
                      )}
                    >
                      <Smartphone className="w-8 h-8 group-hover:scale-110 transition-transform" />
                      <span className="text-xs font-black uppercase tracking-widest">M-Pesa STK</span>
                    </button>
                    <button 
                      onClick={() => setMethod('visa')}
                      className={cn(
                        "flex flex-col items-center gap-3 p-6 rounded-2xl border transition-all group",
                        method === 'visa' ? "bg-money-orange/10 border-money-orange text-money-orange" : "bg-blue-950/20 border-money-orange/10 text-blue-400/40"
                      )}
                    >
                      <CreditCard className="w-8 h-8 group-hover:scale-110 transition-transform" />
                      <span className="text-xs font-black uppercase tracking-widest">Visa/Bank</span>
                    </button>
                  </div>

                  <button 
                    onClick={handleDeposit}
                    disabled={!amount || Number(amount) <= 0}
                    className="w-full bg-linear-to-br from-money-orange to-money-gold text-black py-5 rounded-2xl font-black text-lg shadow-xl shadow-money-orange/20 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50 uppercase tracking-widest"
                  >
                    Initiate Deposit
                  </button>
                </motion.div>
              )}

              {step === 'processing' && (
                <motion.div 
                  key="processing"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-10 space-y-6"
                >
                  <div className="w-24 h-24 border-4 border-money-orange border-t-transparent rounded-full animate-spin mx-auto" />
                  <div>
                    <h4 className="text-xl font-black text-blue-300 uppercase tracking-tighter">STK Push Sent</h4>
                    <p className="text-sm text-blue-400/60 mt-2">Please check your phone and enter your M-Pesa PIN to authorize the transaction.</p>
                  </div>
                  <div className="bg-blue-950/40 p-4 rounded-2xl border border-money-orange/10">
                    <p className="text-[10px] font-black text-money-orange uppercase tracking-widest mb-1">Waiting for confirmation...</p>
                    <div className="h-1 bg-blue-900/20 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: '100%' }}
                        transition={{ duration: 5 }}
                        className="h-full bg-money-orange"
                      />
                    </div>
                  </div>
                </motion.div>
              )}

              {step === 'success' && (
                <motion.div 
                  key="success"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-10 space-y-6"
                >
                  <div className="w-24 h-24 bg-money-green/20 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="text-money-green w-12 h-12" />
                  </div>
                  <div>
                    <h4 className="text-2xl font-black text-money-green uppercase tracking-tighter">Transaction Verified</h4>
                    <p className="text-sm text-blue-400/60 mt-2">Your balance has been updated successfully.</p>
                  </div>
                  <button 
                    onClick={() => setStep('input')}
                    className="w-full py-4 rounded-2xl bg-blue-900/20 text-blue-300 font-black uppercase tracking-widest border border-money-orange/10"
                  >
                    Done
                  </button>
                </motion.div>
              )}

              {step === 'failed' && (
                <motion.div 
                  key="failed"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-10 space-y-6"
                >
                  <div className="w-24 h-24 bg-money-red/20 rounded-full flex items-center justify-center mx-auto">
                    <XCircle className="text-money-red w-12 h-12" />
                  </div>
                  <div>
                    <h4 className="text-2xl font-black text-money-red uppercase tracking-tighter">Transaction Failed</h4>
                    <p className="text-sm text-blue-400/60 mt-2">The STK push was cancelled or timed out. Please try again.</p>
                  </div>
                  <button 
                    onClick={() => setStep('input')}
                    className="w-full py-4 rounded-2xl bg-blue-900/20 text-blue-300 font-black uppercase tracking-widest border border-money-orange/10"
                  >
                    Try Again
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="bg-linear-to-br from-money-orange/10 to-money-gold/5 border border-money-orange/20 rounded-[32px] p-8">
            <div className="flex items-center gap-4 mb-4">
              <div className="p-2 bg-money-orange/20 rounded-lg">
                <CheckCircle2 className="text-money-orange w-5 h-5" />
              </div>
              <h4 className="font-black text-foreground tracking-tight">Secure Payments</h4>
            </div>
            <p className="text-sm text-foreground/60 leading-relaxed">
              All transactions are encrypted and processed through secure gateways. M-Pesa payments are instant, while Visa/Mastercard may take up to 2 minutes to reflect.
            </p>
          </div>
        </div>

        {/* History Section */}
        <div className="glass-card p-10 flex flex-col">
          <h3 className="text-2xl font-black text-foreground mb-8 flex items-center gap-4">
            <div className="p-2 bg-money-blue/10 rounded-xl">
              <History className="text-money-blue w-6 h-6" />
            </div>
            Transaction History
          </h3>

          <div className="flex-1 space-y-4 overflow-y-auto max-h-[600px] pr-2">
            {transactions.length === 0 ? (
              <div className="text-center py-20 text-foreground/20">
                <History size={48} className="mx-auto mb-4 opacity-10" />
                <p className="text-sm font-bold uppercase tracking-widest">No transactions yet</p>
              </div>
            ) : (
              transactions.map((tx, i) => (
                <motion.div 
                  key={tx.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center justify-between p-5 bg-foreground/5 border border-custom rounded-2xl hover:border-foreground/10 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center",
                      tx.type === 'deposit' ? "bg-money-green/10 text-money-green" : "bg-money-orange/10 text-money-orange"
                    )}>
                      {tx.type === 'deposit' ? <ArrowUpCircle size={20} /> : <ArrowDownCircle size={20} />}
                    </div>
                    <div>
                      <p className="text-sm font-black text-foreground uppercase tracking-tight">{tx.type}</p>
                      <p className="text-[10px] font-bold text-foreground/30 uppercase tracking-widest">{new Date(tx.timestamp).toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={cn(
                      "text-lg font-black tracking-tighter",
                      tx.type === 'deposit' ? "text-money-green" : "text-foreground"
                    )}>
                      {tx.type === 'deposit' ? '+' : '-'}{CURRENCY} {tx.amount.toFixed(2)}
                    </p>
                    <div className="flex items-center gap-1 justify-end">
                      {tx.status === 'completed' ? <CheckCircle2 size={10} className="text-money-green" /> : <Clock size={10} className="text-money-gold" />}
                      <span className="text-[10px] font-black text-money-orange uppercase tracking-widest">{tx.status}</span>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
